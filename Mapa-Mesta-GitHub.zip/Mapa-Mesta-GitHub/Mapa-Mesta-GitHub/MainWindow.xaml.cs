﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace Mapa_Mesta_GitHub
{
    public partial class MainWindow : Window
    {
        // ❌ SMAZÁNO: private object txtItem;

        public ObservableCollection<Film> Filmy { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            Filmy = new ObservableCollection<Film>();

            Filmy.Add(new Film
            {
                Nazev = "Matrix",
                Reziser = "Wachowski",
                RokVydani = 1999,
                Zanr = "Sci-Fi",
                Videne = true
            });

            dgFilmy.ItemsSource = Filmy;
        }

        private void Add_click(object sender, RoutedEventArgs e)
        {
            // txtItem je TextBox z XAML (musí mít x:Name="txtItem")
            if (string.IsNullOrWhiteSpace(txtItem.Text))
            {
                MessageBox.Show("Zadejte film");
                return;
            }

            lstItem.Items.Add(txtItem.Text);

            // oprava překlepu
            txtItem.Clear();
        }
    }

    public class Film
    {
        public string Nazev { get; set; }
        public string Reziser { get; set; }
        public int RokVydani { get; set; }
        public string Zanr { get; set; }
        public bool Videne { get; set; }
    }
}