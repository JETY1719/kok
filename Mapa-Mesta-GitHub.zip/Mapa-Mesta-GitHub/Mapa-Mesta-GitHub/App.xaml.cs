﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Mapa_Mesta_GitHub
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
